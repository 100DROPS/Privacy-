package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Professional Corporate Attendance Palette
val Navy900 = Color(0xFF0F172A)
val Navy800 = Color(0xFF1E293B)
val Navy700 = Color(0xFF334155)

val PrimaryBlue = Color(0xFF1E40AF)
val PrimaryBlueDark = Color(0xFF1E3A8A)
val PrimaryBlueLight = Color(0xFF3B82F6)

val EmeraldSuccess = Color(0xFF059669)
val EmeraldSuccessLight = Color(0xFF10B981)
val EmeraldBg = Color(0xFFECFDF5)

val AmberWarning = Color(0xFFD97706)
val AmberBg = Color(0xFFFFFBEB)

val RoseDanger = Color(0xFFE11D48)
val RoseBg = Color(0xFFFFF1F2)

val SlateSurface = Color(0xFFF8FAFC)
val CardBorder = Color(0xFFE2E8F0)
val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val TextMuted = Color(0xFF94A3B8)
